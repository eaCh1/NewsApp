package com.example.android.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by eachunn on 3/10/17.
 */

public class StoryAdapter extends ArrayAdapter {

    public StoryAdapter(Context context, List<Story> stories) {super(context, 0, stories);}

    //Returns a list item view with the desired story information in the list of stories
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //Check to see if there is an existing list item view to add, otherwise, create a new layout
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);

        }

        //Construct instance of a Story, and get position of the Item in the Adapter
        Story currentStory = (Story) getItem(position);

        //Find the TextView with ID Title
        TextView titleView = (TextView) listItemView.findViewById(R.id.title);

        //Set the title of the current story in the TextView
        titleView.setText(currentStory.getTitle());

        //Find the TextView with ID section
        TextView sectionView = (TextView) listItemView.findViewById(R.id.section);

        //Set the section of the current volume in the TextView
        sectionView.setText(currentStory.getSection());

        //Return the list item view with the information
        return listItemView;
    }

}
