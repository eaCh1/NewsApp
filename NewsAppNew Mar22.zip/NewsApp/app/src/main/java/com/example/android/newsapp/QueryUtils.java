package com.example.android.newsapp;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by eachunn on 3/21/17.
 */

public final class  QueryUtils {

    /** Tag for the log messages */
    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    //Create a private constructor to hold static variables

    private QueryUtils() {}

    //Query the Guardian site with a URL and return a List of multiple Stories

    public static List<Story> fetchStories (String requestUrl) {
    //Create a URL object
    URL url = createUrl(requestUrl);

    String jsonResponse = null;

    try {
        jsonResponse = makeHttpRequest(url);
    } catch (IOException e) {
        Log.e(LOG_TAG, "Problem making the HTTP request.", e);
    }

    List<Story> stories = extractFeatureFromJson(jsonResponse);

    return stories;

    }


    //Create URL object and returns Object from the given string URL
    private static URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Problem building the URL ", e);
        }
        return url;

    }

    //Make an HTTP request to the given URL and return a String
    private static String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = "";

        //If the Url is null then return it early before things get sticky

        if (url == null) {
            return jsonResponse;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(1000);
            urlConnection.setConnectTimeout(1500);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            //If connection was succesful(response code 200),
            //then read the input stream and parse the response.
            if(urlConnection.getResponseCode() == 200) {
              inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.e(LOG_TAG, "Issue retrieving the Story JSON result", e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if(inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    private static List<Story> extractFeatureFromJson (String storyJSON) {
        // If the JSON string is empty or null, then return early.
        if (TextUtils.isEmpty(storyJSON)) {
            return null;
        }

        // Create an empty ArrayList to fill with Stories
        List<Story> stories = new ArrayList<>();

        //Parse the JSON response, if there's an issue, throw an JSONException object
        //Catch the exception so the app doesn't crash

        try {

            // Create a JSONObject from the JSON response string
            JSONObject baseJsonResponse = new JSONObject(storyJSON);

            JSONArray storyArray = baseJsonResponse.getJSONArray("response");
            //For each story in the storyArray, create an Story object
            for (int i = 0; i < storyArray.length(); i++) {
                //Get a single Story at position i within the list of stories
                JSONObject currentStory = storyArray.getJSONObject(i);

                JSONObject results = currentStory.getJSONObject("results");

                //Extract the value fot the key "webTitle"
                String title = results.getString("webTitle");

                //Extract the value for the key "sectionName"
                String section = results.getString("sectionName");

                //Extract the value of the key "webUrl"
                String url = results.getString("webUrl");

                //Create a new Story object with the webTitle, sectionName and webUrl
                Story story = new Story(title, section, url);

                //Add the new Story to the list of stories
                stories.add(story);

            }

        } catch (JSONException e) {
            Log.e("QueryUtils", "Problem parsing the story JSON results", e);
        }

        return stories;

    }
}
