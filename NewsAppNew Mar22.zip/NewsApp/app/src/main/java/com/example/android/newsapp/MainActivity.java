package com.example.android.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.app.LoaderManager.LoaderCallbacks;

import java.util.ArrayList;
import java.util.List;

import static com.example.android.newsapp.QueryUtils.fetchStories;

public class MainActivity extends AppCompatActivity implements LoaderCallbacks<List<Story>> {

    private static final String LOG_TAG = MainActivity.class.getName();

    // URL to request Stories from the Guardian regarding Trump
    private static final String GUARDIAN_REQUEST_URL = "http://content.guardianapis.com/search?q=trump&api-key=test";

    private static final int STORY_LOADER_ID = 1;

    private StoryAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView storyListView = (ListView) findViewById(R.id.list);

        mAdapter = new StoryAdapter(this, new ArrayList<Story>());

        storyListView.setAdapter(mAdapter);

        //Check thte stat of the network connection
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        //Get details on the currently active network
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        // If there's Internet, fetch the stories
        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();


            loaderManager.initLoader(STORY_LOADER_ID, null, this);

        }


        storyListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Story currentStory = (Story) mAdapter.getItem(position);

                // Convert the String URL into a URI object (to pass into the Intent constructor)
                 Uri storyUri = Uri.parse(currentStory.getUrl());

                // Create a new intent to view the story URI
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, storyUri);

                // Send the intent to launch a new activity
                startActivity(websiteIntent);
            }
        });

    }

    @Override
    public Loader<List<Story>> onCreateLoader(int i, Bundle bundle) {


        return new StoryLoader(this, GUARDIAN_REQUEST_URL);

    }

    @Override
    public void onLoadFinished(Loader<List<Story>> loader, List<Story> stories) {

        mAdapter.clear();

        if (stories != null && !stories.isEmpty()) {
            mAdapter.addAll(stories);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<Story>> loader) {

        mAdapter.clear();
    }




}
