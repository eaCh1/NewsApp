package com.example.android.newsapp;

import java.util.List;
import android.content.AsyncTaskLoader;
import android.content.Context;

/**
 * Created by eachunn on 3/10/17.
 */

public class StoryLoader extends AsyncTaskLoader<List<Story>> {

    // Member variable for the URL
    private String mUrl;

    /* Constructor for new StoryLoader
     * @param context of activity
     * @param url to load
     */

    public StoryLoader (Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() { forceLoad();}

    @Override
    public List<Story> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        List<Story> stories = QueryUtils.fetchStories(mUrl);
        return stories;

    }
}
