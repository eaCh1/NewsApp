package com.example.android.newsapp;

import java.net.URL;

/**
 * Created by eachunn on 3/10/17.
 */

public class Story {

    // Title of the Story
    private String mTitle;

    //News Section in The Guardian
    private String mSection;

    private String mUrl;


    //Constructor for a Story
    public Story (String title, String section, String url) {
        mTitle = title;
        mSection = section;
        mUrl = url;
    }

    // Get method to return Title
    public String getTitle() {return mTitle;}

    //Get method to return Section

    public String getSection() {return mSection;}

    //Get method to return Url
    public String getUrl() {return mUrl;}

}
